<!DOCTYPE html>
<html>
<body>
<style></style>
<h1>Map Location By Distance</h1>
<left><a href="g.php">Login</a></left>
<p>List of Map Location</p>
<hr>

<?php
$i = 1;
foreach (glob("*.html") as $filename) {
    
    $f= $filename;
  
    echo $i++ .". <a href='$f'>$f</a><br>";
    
}


?>
</body>
</html>




