<?php
  if( $_GET["from"] || $_GET["to"] || $_GET["dist"] || $_GET["map"] ) {

   }

$from = $_GET["from"];
$to = $_GET["to"];
$dist = $_GET["dist"];
$map = $_GET["map"];
$remove= $page = str_replace('"', "'", $map);

$text= 
"<center><h1>Distance from $from to $to</h1>
<h2>Distance from $from to $to is $dist miles.</h2>
<br>
<br>
$remove

</center>";


$fname = "distance-from-$from-to-$to.html";

file_put_contents($fname, $text);

header('Location: '.$fname);
?>