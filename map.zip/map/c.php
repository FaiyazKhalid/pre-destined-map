<?php
$i = 1;
foreach (glob("*.html") as $filename) {
    
    $f= $filename;
  
    echo $i++ .". <a href='$f'>$f</a><br>";
    
}


?>